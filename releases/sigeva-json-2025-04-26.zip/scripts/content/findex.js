window.FINDEX = {
    "/eva/bcoProduccionArticuloPublicacion.do": "articles",
    "/eva/bcoPrecargarArticulo.do": "articles",
    "/eva/bcoProduccionListaPublicacionCapituloLibro.do": "chapters",
    "/eva/bcoProduccionListaPublicacionCongreso.do": "congress",
};
