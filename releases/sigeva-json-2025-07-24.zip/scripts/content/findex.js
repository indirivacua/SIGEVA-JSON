window.FINDEX = {
    "/eva/bcoProduccionArticuloPublicacion.do": "revista",
    "/eva/bcoPrecargarArticulo.do": "revista",
    "/eva/bcoBuscarRevistaPublicacion.do": "revista",
    "/eva/bcoProduccionListaPublicacionCapituloLibro.do": "capitulo",
    "/eva/bcoProduccionListaPublicacionCongreso.do": "congreso",
};
